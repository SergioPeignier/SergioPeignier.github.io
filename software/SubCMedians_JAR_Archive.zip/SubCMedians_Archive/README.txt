This archive provides an implementation of SubCMedians as a Knime component.
The Knime version is about 2.5 times slower, compare to the C++ Python module.


The provided archive contains the following files:

- README.txt (this file)

- org.demo.subcmedians.lite_0.8.2.jar the jar archive file

- Two datasets (ARFF format) from the UCI Machine Learning Repository used in the
  paper:
    * diabetes.arff
    * pendigits.arff
All datasets considered in the experiments in the paper are those used in [1]. These datasets
are made available by the authors of [1] at their website:
http://dme.rwth-aachen.de/openSubspace/evaluation.

- One more dataset (ARFF format) also from the UCI Machine Learning Repository
    * iris.arff (not particularly interesting for subspace clustering, but well known)


[1] E. Muller, S. Gunnemann, I. Assent, and T. Seidl, “Evaluating clustering in subspace projections of high dimensional data,” in Proc. 35th Int. Conf. on Very Large Data Bases (VLDB 2009), Lyon, France, 2009, pp. 1270–1281.

=====================================================================================
INSTALLING THE COMPONENT
========================

This component has been tested using Knime version 3.1.1.

One way to install the SubsCmedian Knime component easily is to copy the file "org.demo.subcmedians.lite_0.8.2.jar"
to the "dropins/" folder located in the "KNIME/" or "Eclipse/" folder of your Knime installation folder.
On Mac OS X the "dropins/" folder is under the Knime application, right-click on Knime and select "Show Package Content".
In case Knime is currently running restart the program.

Henceforth the SubsCmedian component should be available in Knime "Node Repository".


=====================================================================================
USING THE COMPONENT
===================

Pre-processing and post-processing
----------------------------------

Two pre-processings are required for best results:

- Shuffle the dataset rows (component "Shuffle")

- Z-Score Normalization (component "Normalizer")


Post-processing:

- If necessary, the "Domain Calculator" component can be used to remove unused cluster
  labels from the domain.



Parameter settings
------------------

SubsCmedian component can be used with an "Easy settings" mode. In this case the user
provides a unique parameter: Kexp, i.e., the expected number of clusters in the 
dataset. Then the real algorithm parameters are computed as recommended in the paper:

- Maximal Model Size   =  Kexp * D
- Sample size          =  25 * Kexp 
- Number of iterations =  10 * Kexp * Maximal Model Size

Where D denotes the number of dimensions in the dataset.

The "Easy settings" mode can 
be particularly useful for a first guess, to see if some structure seems to be 
exhibited for this level of details. Of course as for all subspace clustering algorithm,
obtaining useful is likely to require a finer parameter setting, and
several repetitions of the clustering process. In order to set each parameter 
independently, the user should unselect the "Easy settings" mode.


Datasets and Easy settings
--------------------------

The first dataset is Diabetes. This dataset is rather small, it contains 768 objetcs
in 8 dimensions. This dataset is structured in two classes, these classes are largely 
overlapping and do not clearly corresponds to clusters.
SubCMeans easy setting: Expect cluster numbers = 6
(3 times the number of classes)

The second dataset is Pendigits. This dataset is a larger dataset since it contains 7494 
objects in 16 dimensions. This dataset is structured in ten classes. Some classes 
or groups of classes tend to form distinct clusters.
SubCMeans easy setting: Expected cluster numbers = 30
(3 times the number of classes)
This dataset requires a longer runtime (about 1400 seconds in Knime on standard laptop)

The last dataset is Iris. This dataset is rather small, it contains 150 objects
in 4 dimensions. This dataset is structured in three classes. One of the classes tends
to form a distinct cluster and the remaining two classes tend to be splitted in more
clusters.
SubCMeans easy setting: 3 clusters

-----------------------------------------------------------------------------------------------------
