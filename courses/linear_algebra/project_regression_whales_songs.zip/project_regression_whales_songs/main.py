import numpy as np
from pathlib import Path

DATA_DIR = Path.home() / ".cache/huggingface/hub/datasets--monster-monash--WhaleSounds/snapshots"
snapshot_dir = next(DATA_DIR.iterdir())

X = np.load(snapshot_dir / "WhaleSounds_X.npy")
y = np.load(snapshot_dir / "WhaleSounds_y.npy")

print(X.shape)
print(y.shape)




import librosa
import numpy as np
# Compute STFT magnitude spectrogram
S = np.abs(librosa.stft(X[0,:,:], n_fft=1024, hop_length=256))
print(S.shape)


import soundfile as sf
# Sampling rate
sr = 250  # Hz
# Save temporary WAV
wav_path = Path("example_whale_signal.wav")
sf.write(wav_path, (X[1000,0,:] - X[1000,0,:].mean())/X[1000,0,:].std(), sr)






from sklearn.decomposition import DictionaryLearning
dict_learner_1 = DictionaryLearning(
    n_components=30,
    transform_algorithm="omp"
)
Z = dict_learner_1.fit_transform(X[np.random.choice(range(X.shape[0]),size=3000,replace=False)])
dict_learner_1


from sklearn.decomposition import DictionaryLearning
dict_learner_2 = DictionaryLearning(
    n_components=300,
    transform_algorithm="omp"
)
Z = dict_learner_2.fit_transform(X[np.random.choice(range(X.shape[0]),size=3000,replace=False)])

